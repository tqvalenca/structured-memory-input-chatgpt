MIT License

Copyright (c) 2025 Tiago Valença

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction...

[truncated for brevity — full MIT license will be included in actual file]
